package com.example.easy_message

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
